export * from "./connection";
export const LamportPerSOL = 1000000000;
